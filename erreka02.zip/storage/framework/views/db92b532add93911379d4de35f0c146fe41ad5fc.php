

        <!-- component -->
         <!--CONTENIDO-->

        <form method="post" enctype="multipart/form-data" action="<?php echo e(url('/buscarfactura')); ?>" data-toogle="validator" role="form" id="logo_form">
          <?php echo e(csrf_field()); ?>



          <div class="form-group">
            <input type="text" name="factura" autocomplete="off" id="factura" class="form-control input-sm btn" placeholder="codigo factura">
            <button type="submit" class="btn btn-primary button">Buscar</button>
          </div>


        </form>
        <!--fin de contenido-->
<!-- This is an example component -->
    <div class="mt-6 py-6 border-t border-slate-200 text-center">
                <h3>Facturas</h3>
             </div>

             <div class="max-w-2xl mx-auto">
    <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th scope="col" class="px-6 py-3">
                            Código
                        </th>
                        <th scope="col" class="px-6 py-3">
                            fecha
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Pagado
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Cliente
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Vehículo
                        </th>
                        <th scope="col" class="px-6 py-3">
                            editar
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-white border-b">

              <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                <a href="<?php echo e(url('/infofactura')); ?>/<?php echo $factura->id; ?>"><button class="btn btn-primary button"><?php echo $factura->cod_factura; ?></button></a>
              </td>
              <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                <?php echo $factura->created_at->format('d-m-Y'); ?>

              </td>
              <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                <?php echo $factura->pagado; ?>

              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo $factura->cliente->nombre; ?> <?php echo $factura->cliente->apellido; ?></td>
              <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                <?php echo $factura->vehiculo->matricula; ?>

              </td>
              <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                    <a href="<?php echo e(url('/editfactura')); ?>/<?php echo $factura->id; ?>" class="button">editar</a>
                  </td>
            </tr class="bg-white border-b">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\erreka02\resources\views/components/facturas-layout.blade.php ENDPATH**/ ?>