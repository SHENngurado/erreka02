<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

  <div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
        <!-- component -->
        <!--CONTENIDO-->

        <form method="post" enctype="multipart/form-data" action="<?php echo e(url('/buscarvehiculo')); ?>" data-toogle="validator" autocomplete="off" role="form" id="logo_form">
          <?php echo e(csrf_field()); ?>



          <div class="form-group">
            <input type="text" name="matricula" autocomplete="off" class="form-control input-sm btn" placeholder="matricula">
            <button type="submit" class="btn btn-primary button">Buscar</button>
          </div>


        </form>
        <!--fin de contenido-->
        <!-- This is an example component -->
        <div class="mt-6 py-6 border-t border-slate-200 text-center">
          <h3>Vehículos</h3>
        </div>

        <div class="max-w-2xl mx-auto">
          <div class="relative overflow-x-auto shadow-md sm:rounded-lg">

            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
              <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    Matrícula
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Marca y Modelo
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Cliente
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Editar
                  </th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-white border-b">
                  <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><a href="<?php echo e(url('/infovehiculo')); ?>/<?php echo $vehiculo->id; ?>"><?php echo $vehiculo->matricula; ?></a></td>
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                    <?php echo $vehiculo->marca; ?>-<?php echo $vehiculo->modelo; ?>

                  </td>
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                    <?php echo $vehiculo->cliente->nombre; ?> <?php echo $vehiculo->cliente->apellido; ?>

                  </td>
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                    <a href="<?php echo e(url('/editvehiculo')); ?>/<?php echo $vehiculo->id; ?>" class="button">editar</a>
                  </td>
                </tr class="bg-white border-b">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\erreka02\resources\views/vehiculos.blade.php ENDPATH**/ ?>