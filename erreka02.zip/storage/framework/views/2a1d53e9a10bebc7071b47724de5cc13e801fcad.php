<svg viewBox="0 0 317 48" fill="none" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>
  <div class="flex justify-start">
    Bienvenido/a <?php echo e(Auth::user()->name); ?>

</div>
</svg><?php /**PATH C:\xampp\htdocs\erreka02\resources\views/vendor/jetstream/components/application-logo.blade.php ENDPATH**/ ?>