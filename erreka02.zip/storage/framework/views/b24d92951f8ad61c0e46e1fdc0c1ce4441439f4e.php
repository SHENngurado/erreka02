<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-6 py-4">
        <div class="text-center mt-2">
            <h3 class="text-2xl text-slate-700 font-bold leading-normal mb-1"><?php echo $cliente->nombre; ?> <?php echo $cliente->apellido; ?></h3>
    <form method="post" enctype="multipart/form-data" action="<?php echo e(url('/editclienteguardar')); ?>" data-toogle="validator" role="form" id="logo_form">
    <?php echo e(csrf_field()); ?>

    <h1>EDITAR</h1>
    <table id="customers2">
      <tbody>
        <tr>
          <td>
            <br>
            <br>
            <nav>
              <ul>
                <li>Nombre:  <input type="text" name="nombre" value="<?php echo $cliente->nombre; ?>"  /></li>
                <li>Apellido:  <input type="text" name="apellido" value="<?php echo $cliente->apellido; ?>" size="30"  /></li>
                <li>CIF/DNI:  <input type="text" name="cifdni" value="<?php echo $cliente->cifdni; ?>" /></li>
                <input hidden type="text" name="id" value="<?php echo $cliente->id; ?>" />
              </ul>
            </nav>
          </td>
        </tr>
      </tbody>
      <tbody>
        <tr>
          <td>
            <nav>
              <ul>
                <li>Telefono:  <input type="text" name="telefono" value="<?php echo $cliente->telefono; ?>"  /></li>
                <li>Correo:  <input type="text" name="correo" value="<?php echo $cliente->correo; ?>" size="30" /></li>
              </ul>
            </nav>
          </td>
           </tbody>
      <tbody>
          <td>
            <nav>
              <ul>
                <li>Calle:  <input type="text" name="calle" value="<?php echo $cliente->calle; ?>" size="30" /></li>
                <li>Portal:  <input type="text" name="portal" value="<?php echo $cliente->portal; ?>"  /></li>
                <li>Piso:  <input type="text" name="piso" value="<?php echo $cliente->piso; ?>" /></li>
                <li>Puerta:  <input type="text" name="puerta" value="<?php echo $cliente->puerta; ?>" /></li>
              </ul>
            </nav>
          </td>
        </tr>
      </tbody>
            <tbody>
          <td>
            <nav>
              <ul>
                <li>Codigo postal:  <input type="text" name="cod_postal" value="<?php echo $cliente->cod_postal; ?>" size="30" /></li>
                <li>Población:  <input type="text" name="poblacion" value="<?php echo $cliente->poblacion; ?>"  /></li>
                <li>Provincia:  <input type="text" name="provincia" value="<?php echo $cliente->provincia; ?>" /></li>
              </ul>
            </nav>
          </td>
        </tr>
      </tbody>
    </table>
    <br>

  </div>

  <button type="submit" class="btn btn-primary button">Guardar</button>
</form>
        </div>
</div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\erreka02\resources\views/editcliente.blade.php ENDPATH**/ ?>