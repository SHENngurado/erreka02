<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">

                <div class="px-6">

                    <div class="text-center mt-2">
                        <h3 class="text-2xl text-slate-700 font-bold leading-normal mb-1"><?php echo $vehiculo->matricula; ?> <?php echo $vehiculo->marca; ?> <?php echo $vehiculo->modelo; ?></h3>
                        <div class="text-xs mt-0 mb-2 text-slate-400 font-bold uppercase">
                            <a href="<?php echo e(url('/infocliente')); ?>/<?php echo $vehiculo->cliente->id; ?>"><?php echo $vehiculo->cliente->nombre; ?> <?php echo $vehiculo->cliente->apellido; ?></a>
                        </div>
                        <div class="text-xs mt-0 mb-2 text-slate-400 font-bold uppercase">
                            <?php echo $vehiculo->cliente->telefono; ?>  -  <?php echo $vehiculo->cliente->correo; ?>

                        </div>
                    </div>
                    <!-- component tabla-->
                    <!-- This is an example component -->
                    <div class="mt-6 py-6 border-t border-slate-200 text-center">
                        <h3>Facturas</h3>
                    </div>
                    <div class="max-w-2xl mx-auto">
                        <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                            <div class="p-4">
                                <div class="relative mt-1">
                                    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">

                                    </div>
                                    <input type="text" id="table-search" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-80 pl-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Search for items">
                                </div>
                            </div>
                            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                    <tr>
                                        <th scope="col" class="px-6 py-3">
                                            Número
                                        </th>
                                        <th scope="col" class="px-6 py-3">
                                            Fecha
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="bg-white border-b">
                                      <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><a href="<?php echo e(url('/infofactura')); ?>/<?php echo $factura->id; ?>"><?php echo $factura->id; ?></a></td>
                                      <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                                        <?php echo $factura->created_at->format('d-m-Y'); ?>

                                    </td>
                                </tr class="bg-white border-b">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- fin component tabla -->
            </div>
        </div>
    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\erreka02\resources\views/infovehiculo.blade.php ENDPATH**/ ?>