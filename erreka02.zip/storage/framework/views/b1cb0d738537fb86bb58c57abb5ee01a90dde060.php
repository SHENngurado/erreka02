<!-- component -->
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 ">
            <div class="relative max-w-md mx-auto md:max-w-2xl mt-6 min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded-xl mt-16 py-2">

             <!-- component -->
                   <div class="bg-white overflow-hidden sm:rounded-lg px-3 py-2">
        <!--CONTENIDO-->
        
        <p>Buscar por codigo factura</p>

        <form method="post" enctype="multipart/form-data" action="<?php echo e(url('/buscafactura')); ?>" data-toogle="validator" role="form">
          <?php echo e(csrf_field()); ?>



          <div class="form-group">
            <input type="text" name="cod_factura" class="form-control input-sm btn" placeholder="Codigo factura" required>
            <button type="submit" class="btn btn-primary button">Buscar</button>
          </div>


        </form>
        <!--fin de contenido-->
      </div>
             <!-- This is an example component -->
             <div class="text-center mt-2 py-4">
                <h3 class="text-2xl text-slate-700 font-bold leading-normal mb-1">Contabilidad</h3>

            </div>
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th scope="col" class="px-6 py-3">
                            Código
                        </th>
                        <th scope="col" class="px-6 py-3">
                            fecha
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Pagado
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Cliente
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Vehículo
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bg-white border-b">

                      <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                        <a href="<?php echo e(url('/infofactura')); ?>/<?php echo $factura->id; ?>"><button class="btn btn-primary button"><?php echo $factura->cod_factura; ?></button></a>
                    </td>
                    <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                        <?php echo $factura->created_at->format('d-m-Y'); ?>

                    </td>
                    <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                        <a href="<?php echo e(url('/editpagado')); ?>/<?php echo $factura->id; ?>" class="button"><?php echo $factura->pagado; ?></a>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo $factura->cliente->nombre; ?> <?php echo $factura->cliente->apellido; ?></td>
                    <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                        <?php echo $factura->vehiculo->matricula; ?>

                    </td>
                </tr class="bg-white border-b">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\erreka02\resources\views/contabilidad.blade.php ENDPATH**/ ?>