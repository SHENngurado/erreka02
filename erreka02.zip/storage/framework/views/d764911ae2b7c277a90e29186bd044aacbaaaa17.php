<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
              <a class="button" href="<?php echo e(url('/infofacturapdf')); ?>/<?php echo $factura->id; ?>" style="display: block;margin-left: auto;margin-right: auto;width: 40%;">Imprimir factura</a>
              <br>
        <!-- component -->
<div class="h-screen flex flex-col items-left justify-center background-blue">

    <!-- Card 1 -->
  <card class="py-7 px-5">
    <div class="grid grid-cols-6 gap-1">
      
      <!-- Description -->
      <div class="col-span-6">
        <p class="">Factura Nº: <?php echo $factura->cod_factura; ?></p>
        <p class="text-gray-500 ">Orden/Albaran: <?php echo $factura->or_id; ?></p>
        <p class="text-gray-500 ">Marca: <?php echo $factura->vehiculo->marca; ?></p>
        <p class="text-gray-500 ">Modelo: <?php echo $factura->vehiculo->modelo; ?></p>
        <p class="">Matricula: <?php echo $factura->vehiculo->matricula; ?></p>
        <p class="">KMS: <?php echo $factura->kms; ?></p>
      </div>
    </div>
  </card>
      <!-- Card 1 -->
  <card class="py-7 px-5">
    <div class="grid grid-cols-6 gap-1">
      
      <!-- Description -->
      <div class="col-span-6">
        <p class="">Cliente: <?php echo $factura->cliente->nombre; ?> <?php echo $factura->cliente->apellido; ?></p>
        <p class="text-gray-500 ">Cod. Cliente: <?php echo $factura->cliente->id; ?></p>
        <p class="">CIF/DNI: <?php echo $factura->cliente->cifdni; ?></p>
        <p class="text-gray-500 ">tlf: <?php echo $factura->cliente->telefono; ?></p>
        <p class="text-gray-500 ">fecha: <?php echo $factura->created_at->format('d-m-Y'); ?></p>
        <p class="text-gray-500 ">Ref. Cliente: <?php echo $datos->ref_cliente; ?></p>
      </div>

    </div>
  </card>
  <!-- Mano de obra -->
  <br>
  <h1>Mano de obra</h1>
  <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
              <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    Denominación
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Tiempo
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Precio
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Importe
                  </th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $factura->manodeobras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manodeobra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-white border-b">
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo $manodeobra->nombre; ?></td>
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo $manodeobra->tiempo; ?></td>
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo $manodeobra->euroshora; ?></td>
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo $manodeobra->importe; ?></td>
                </tr class="bg-white border-b">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
                  <tr>
                  <th scope="col" class="px-6 py-3">
                    
                  </th>
                  <th scope="col" class="px-6 py-3">
                    
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Total mano de obra:
                  </th>
                  <th scope="col" class="px-6 py-3">
                    <?php echo $summanodeobras; ?>

                  </th>
                </tr>
              </tfoot>
            </table>
  <!-- Materiales y trabajos exteriores -->
  <h1>Materiales y trabajos exteriores</h1>
  <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
              <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    Denominación
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Cantidad
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Precio
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Importe
                  </th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $consumibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consumible): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-white border-b">
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo $consumible->nombre; ?></td>
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo $consumible->cantidad; ?></td>
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo $consumible->preciounidad; ?></td>
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo $consumible->importe; ?></td>
                </tr class="bg-white border-b">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
                  <tr>
                  <th scope="col" class="px-6 py-3">
                    
                  </th>
                  <th scope="col" class="px-6 py-3">
                    
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Total materiales:
                  </th>
                  <th scope="col" class="px-6 py-3">
                    <?php echo $sumconsumibles; ?>

                  </th>
                </tr>
              </tfoot>
            </table>
            <BR>
            <!-- TOTAL -->
  <h1>TOTAL</h1>
<table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
              <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    Importe Neto
                  </th>
                  <th scope="col" class="px-6 py-3">
                    IVA %
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Importe IVA
                  </th>
                  <th scope="col" class="px-6 py-3">
                    TOTAL
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr class="bg-white border-b">
                  <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo $importetotal; ?></td>
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo $factura->iva; ?></td>
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo $iva; ?></td>
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo $importetotaliva; ?></td>
                </tr class="bg-white border-b">
              </tbody>
            </table>
</div>
<a class="button" href="<?php echo e(url('/infofacturapdf')); ?>/<?php echo $factura->id; ?>" style="display: block;margin-left: auto;margin-right: auto;width: 40%;">Imprimir factura</a>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\erreka02\resources\views/infofactura.blade.php ENDPATH**/ ?>