<?php

namespace App\View\Components;

use Illuminate\View\Component;
use App\Models\Model\Factura;
use App\Models\Model\Cliente;
use App\Models\Model\Vehiculo;

class InfoclienteLayout extends Component
{
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */

    public function render()
    {
       
        return view('components.infocliente-layout')->with([
            
            ]);
    }
}
